//
// See MapBoxNoduleTestHarness in this git repo for a full usage example.
//